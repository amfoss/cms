﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","sl",{title:"UI Izbiralec Barve",preview:"Živi predogled",config:"Prilepite ta niz v vašo config.js datoteko",predefined:"Vnaprej določeni barvni kompleti"});