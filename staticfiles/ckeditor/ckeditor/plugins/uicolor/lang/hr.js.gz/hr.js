﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","hr",{title:"UI odabir boja",preview:"Pregled uživo",config:"Zalijepite ovaj tekst u Vašu config.js datoteku.",predefined:"Već postavljeni setovi boja"});