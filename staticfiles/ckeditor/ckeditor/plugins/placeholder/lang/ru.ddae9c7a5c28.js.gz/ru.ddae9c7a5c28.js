﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","ru",{title:"Свойства плейсхолдера",toolbar:"Создать плейсхолдер",name:"Имя плейсхолдера",invalidName:'Плейсхолдер не может быть пустым и содержать один из следующих символов: "[, ], <, >"',pathName:"плейсхолдер"});